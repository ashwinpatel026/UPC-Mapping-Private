import HomeScreen from "@/screens/home/home.screen";

export default function index() {
  return <HomeScreen />;
}
