import { View, Text } from "react-native";
import React from "react";
import ProfileScreen from "@/screens/profile/profile.screen";

export default function index() {
  return <ProfileScreen />;
}
