import React from "react";
import ProductShowScreen from "@/screens/product-show/product.screen";

export default function index() {
  return <ProductShowScreen />;
}
