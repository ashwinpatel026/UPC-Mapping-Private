import OnboardingScreen from "@/screens/onboarding/onboarding.screen";

export default function index() {
  return <OnboardingScreen />;
}
